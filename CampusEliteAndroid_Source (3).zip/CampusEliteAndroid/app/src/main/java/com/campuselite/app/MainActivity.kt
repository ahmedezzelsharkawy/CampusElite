package com.campuselite.app

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Color

class MainActivity : Activity() {
 private lateinit var webView: WebView
 @Suppress("SetJavaScriptEnabled")
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  window.statusBarColor = Color.rgb(9,14,27)
  window.navigationBarColor = Color.rgb(9,14,27)
  webView = WebView(this)
  webView.setBackgroundColor(Color.rgb(9,14,27))
  webView.webViewClient = WebViewClient()
  webView.webChromeClient = WebChromeClient()
  webView.settings.apply {
   javaScriptEnabled = true
   domStorageEnabled = true
   databaseEnabled = true
   cacheMode = WebSettings.LOAD_DEFAULT
   allowFileAccess = true
   allowContentAccess = true
   mediaPlaybackRequiresUserGesture = false
  }
  setContentView(webView)
  if (savedInstanceState != null) webView.restoreState(savedInstanceState)
  else webView.loadUrl("file:///android_asset/www/index.html")
 }
 override fun onSaveInstanceState(outState: Bundle) { webView.saveState(outState); super.onSaveInstanceState(outState) }
 @Deprecated("Deprecated in Java")
 override fun onBackPressed() { if (webView.canGoBack()) webView.goBack() else super.onBackPressed() }
 override fun onDestroy() { if (::webView.isInitialized) webView.destroy(); super.onDestroy() }
}
