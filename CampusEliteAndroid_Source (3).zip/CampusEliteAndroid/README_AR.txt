Campus Elite Android — مشروع أندرويد قابل للبناء

المشروع يحتوي على واجهة Campus Elite داخل تطبيق Android WebView، ويفتح الجدول دون إنترنت بعد التثبيت.

مهم: هذا مشروع المصدر وليس APK جاهزًا. لم يتم بناء أو اختبار APK هنا. التنبيهات الدقيقة بعد إغلاق التطبيق تحتاج إضافة نظام تنبيهات أندرويد أصلي، ومشاركة الجدول تحتاج قاعدة بيانات مشتركة.

بناء APK باستخدام Android Studio على كمبيوتر:
1. ثبّت Android Studio.
2. اختر Open وافتح مجلد CampusEliteAndroid.
3. انتظر Gradle Sync.
4. من Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5. ستجد الملف عادةً في app/build/outputs/apk/debug/app-debug.apk.
6. انقل الملف للهاتف وثبّته.

minSdk 23، targetSdk 35، Kotlin + WebView.
